# HIVE / WO-032 / CD20-R6-C5
## Consolidação de candidata B1 sem HIVE local

**Executor:** Codex Desktop, em sessão nova sem MCP HIVE.

**Veredito inicial:** R6-C4 funcional em nova sessão segundo captura; primária do bundle R6-C4 ainda não auditada. WO-032 C07 NOT QUALIFIED. Desinstalação da instalação antiga BLOCKED por segurança de dados.

## OBJECTIVE / OBJETIVO

WO-032, Correction Delta CD20-R6-C5. Consolidar o patch já autorizado e testado apenas em scratch na revisão CD20-R3, fazer a suíte B1 completa em uma cópia LF isolada e produzir evidências verificáveis. O produto HIVE deve ser desenvolvido SEM depender de MCP, API, RAG, corpus, indexação, PostgreSQL ou memória da instalação local HIVE v1.0.3.

Esta ordem NÃO realiza a desinstalação da instalação antiga, NÃO qualifica C07 em dados reais e NÃO abre PR. É a correção do mesmo WO-032/issue #163, não novo Work Order.

## CONTEXT / SOURCE CHECK

Fonte de verdade Git: KayzenRoot/hive. Na preparação deste documento, a main verificada está em f51c13487a21f22c7c8e873c42722bfac5fd88f8. No executor, verificar novamente a main remota LIVE por GitHub autenticado ou git ls-remote origin refs/heads/main, além de conferir o HEAD usado para clonar. Se divergente, CONTEXT LOCK STALE e STOP sem substituir o SHA por conta própria.

Ler nesta ordem os arquivos reais da main: docs/project-brain/13-CHECKPOINT.md, 16-DECISIONS-LEDGER.md, 03-SCOPE.md, 15-DEFINITION-OF-DONE.md, 04-ARCHITECTURE.md, 02-REQUIREMENTS.md; depois AGENTS.md e issue #163, incluindo CD11, autorização CD20-R3 e auditoria CD20-R3.

Snapshot dos Git blob OIDs da main conhecida: checkpoint ae0c8d68da08dea892b27ba0fd05fc83755410c6; ledger 96805ca5318c0e3c28c0e8f9c9462e23f831c6ed; scope 5d57c08a3241aa960622d4d002ff64033316db4b; DoD b5bb40517dfcf2e9dbfc4bffafab9d6ead151e2c; architecture 59de079a9c8c393fe6978a318b4555819400ce48; requirements ab2dc837b176a0a3a9e1b3caa126574cf951fd88. Capturar hashes atuais e STOP em mudança crítica sem autorização.

Patch binário primário CD20-R3: a66ca89917af5eb1db436e85dc2fbe5f64820be9b0b117db7028e417cc5ddb95. O ZIP de distribuição deste prompt inclui o próprio patch verificado extraído do ZIP R3 enviado pelo usuário, sem dados da API antiga. Conferir SHA antes de usar; não reconstruir patch de memória.

## PREFLIGHT: CODEX INDEPENDENTE

O relatório CD20-R6-C4 aponta [mcp_servers.hive].enabled=false e um NOVO processo Codex no qual HIVE aparece disabled, node_repl permanece enabled e um teste Python retorna zero. Essas são declarações da captura; o ZIP de evidências R6-C4 ainda não foi anexado para auditoria primária.

Neste incremento, observar SEM modificar config.toml: identificar o perfil de usuário ativo e somente o estado enabled/disabled da entrada hive, rodar novo processo `codex mcp list` e um comando Python simples sem chamar HIVE. Capturar resultados redigidos, PIDs sem encerrar nenhum, fingerprint da configuração sem copiar segredos ao Evidence Bundle.

Se o HIVE estiver habilitado em nova sessão, se houver ambiguidade de perfil, ou se for necessário alterar qualquer configuração/processo, STOP antes do trabalho de código; devolver apenas evidências. Não reabrir o HIVE local como solução.

## SCOPE / OUT OF SCOPE

SCOPE NECESSARY: reconstruir o patch congelado em scratch LF a partir da base autorizada; revisar o único probe negativo UnapprovedOperator; executar B1 e produzir candidata local reproduzível. A allowlist é EXATAMENTE o conjunto abaixo; caminhos permitidos não significam mudanças obrigatórias além do que existir no patch:

## ALLOWLIST EXATA: 19 PATHS



- `.engineering/release/HIVE-V1.0.3-RELEASE-RECEIPT.json`
- `.gitattributes`
- `README.md`
- `backend/app/semantic_retrieval.py`
- `backend/tests/test_codex_desktop_qualification.py`
- `backend/tests/test_review_evidence.py`
- `backend/tests/test_semantic_retrieval.py`
- `backend/tests/test_verify_canonical_sources.py`
- `benchmarks/fixtures/wo032_c07_retrieval_ground_truth.v1.json.gz`
- `docs/CODEX-DESKTOP.md`
- `docs/INSTALLATION.md`
- `docs/UPGRADING.md`
- `docs/atlas/code-atlas.md`
- `docs/atlas/test-map.md`
- `docs/releases/v1.0.3.md`
- `scripts/codex_desktop_qualification.py`
- `scripts/retrieval_integration.py`
- `scripts/review_evidence.py`
- `scripts/verify_canonical_sources.py`

## OUT OF SCOPE / RESTRIÇÕES

Não usar o HIVE 1.0.3 como contexto, provider, integração ou teste. Não acessar sua API, banco, CAS, Redis, corpus, ferramentas MCP, indexação ou Docker operacional. Não criar, excluir, recriar, fazer backup ou restaurar D:\HIVE neste incremento. Não modificar contêineres, volumes ou serviços existentes.

Não alterar o checkout original dirty em D:\Projects\hive (HEAD histórico 78c466b9e984931c52f0bad62fe4a04931828f5d), nem suas alterações locais, untracked ou .git. Não executar reset/clean, rebase, force push, push, PR, merge, release, WO-036, promoção de checkpoint ou código fora dos 19 caminhos.

Dois mapas Atlas só podem entrar porque CD11 os autorizou condicionalmente e o gerador oficial confirmar equivalência determinística. NÃO admitir docs/atlas/module-registry.md, backend/tests/test_repository_indexer.py, wildcard, path de outro WO nem substituição de operador/autorização por snapshot sintético. Não editar manifestos de release para mascarar CRLF.

## CONTEXT LOCK E RECONSTRUÇÃO EM SCRATCH

1. Confirmar main LIVE=f51c13487a21f22c7c8e873c42722bfac5fd88f8, patch SHA e OIDs canônicos. Registrar base, patch, versão Python e estado de ferramentas. Sem qualquer chamada ao HIVE local.

2. Trabalhar em CLONE INDEPENDENTE descartável com core.autocrlf=false, LF, fora de D:\Projects e de qualquer raiz monitorada. Preferir pasta temporária nova do usuário, com caminho registrado; nunca escrever no checkout original. Resolver branch/remotes sem confundir origin/main cache com refs/heads/main LIVE.

3. Verificar git apply --check --binary sobre o patch congelado; se PASS, aplicar a cópia binária a partir da main exata. Provar o tree/diff final de exatamente 19 caminhos. Se diff, base, binário, mapa ou hashes divergirem: STOP sem improvisar. Registrar SHA256 do patch e sha Git da árvore inicial e final.

4. Provar que scripts/review_evidence.py e backend/tests/test_review_evidence.py mantêm regras WO-032/033, rejeição WO-034, ADR-019/020 e proteções da PR #169. Provar a alteração da fixture .json.gz sem introduzir arquivo JSON legado ou lógica especial por nome no retrieval de produção.

## CORREÇÃO FOCADA: PROBE NEGATIVO

A captura CD20-R4 mostrou que um probe de substituição de operador aceitou em memória UnapprovedOperator. Investigar a causa com o contrato real do validador de Review Evidence. Não assumir que um campo inventado no snapshot seja política vinculante. Verificar quais campos oficiais identificam autor/operador, base, escopo e evidência autenticada.

Reproduzir o teste negativo antes de qualquer modificação de código. Se for defeito real de fail-closed, corrigir somente os arquivos já autorizados do WO-032, com testes de aceitação e rejeição em backend/tests/test_review_evidence.py. Cobrir operador não autorizado, main antiga/drift, path fora da lista, duplicata, marcador ausente e fixture inválida quando o contrato exigir. Se a correção real exigir arquivos fora do conjunto, nova mudança de governança ou política não aprovada: STOP com Correction Delta, sem alargar a allowlist.

Não transformar um teste negativo em PASS modificando a entrada para uma entrada mais fácil nem ignorar o caso original; preservar entrada, resultado obtido, causa e alteração justificada.

## TESTS / EVIDENCE - B1 INDEPENDENTE

Executar na scratch FINAL: python -m pytest sobre backend completo com JUnit XML, sem reutilizar processos do HIVE antigo. Em caso de lentidão, capturar progresso, teste exato e traceback/fault handler no processo da scratch; teste interrompido não é PASS. Corrigir somente falhas introduzidas dentro do escopo aprovado. Provar o teste de substituição de operador, fixture gzip, mapas, release metadata e regressão negativa do gate.

Executar python scripts/validate.py ou conjunto equivalente real definido no CI da main, Ruff check/format, mypy, python compileall, fontes canônicas, segurança/secret scan, geração/verificação de mapas, verificação de release metadata em LF, e dashboard lint/typecheck/build conforme a configuração do repositório. Capturar comandos exatos, exit code, duração, versões e logs completos. Se não houver dependência instalada, identificar explicitamente como BLOCKED, sem PASS fabricado.

Para teste PostgreSQL dedicado anteriormente SKIP por WO032_TEST_POSTGRES_DSN, permitir apenas infraestrutura efêmera e completamente separada que não monte/reutilize D:\HIVE nem portas/volumes da instância antiga, se compatível com o plano de testes canônico; caso contrário manter SKIP declarado e deixar CI Integration health validar quando houver PR. Não usar as credenciais nem o banco antigo.

NÃO executar C07 em corpus antigo. O benchmark histórico real continua reprovado (recall@5 7/23=.304348, MRR .20, cinco misses críticos, mediana warm 1230,883ms). Essa parte será qualificada em instalação FUTURA nova com evidência de HEAD/corpus/semantic e autorização operacional específica; B1 PASS não substitui C07 nem o DoD.

## DELIVERABLES / REVIEW FORMAT

Evidence Bundle em pasta EXTERNA e fora da scratch/roots monitoradas contendo manifesto SHA256: autorização issue #163, live main e OIDs, PATCH_SHA256, novo Codex mcp list redigido, matriz dos 19 caminhos com tipo de mudança, git status inicial/final, prova de integridade do original (somente Git hashes, nunca mover seus arquivos), logs integrais dos testes e gates, JUnit, falhas/reparos, scan, source fingerprint, decisão sobre probe negativo e lista de skips.

Se TODOS os gates independentes B1 passarem e diff final permanecer apenas nos 19 caminhos aprovados, permitir UM commit apenas LOCAL na scratch; registrar sha/base e deixar candidato preparado para auditoria. Nunca publicar PR/push ou promover checkpoint por esse resultado. Se B1 falhar, retornar somente Correction Delta desse mesmo WO-032 com evidência e STOP, não implementar novo incremento.

Review FINAL em português brasileiro: resumo; arquivos e decisões; base/head; testes e logs; lint/typecheck/build; regressões; segurança; riscos; gates PASS/FAIL/SKIP/DEFERRED; pacote/hashes; Checkpoint Delta proposto NONE; indicação OWNER_SELF_AUDIT / NOT INDEPENDENT; confirmação expressa de 0 calls HIVE legado, 0 provider e 0 alterações de dados/Compose.

## STOP CONDITION

PARAR imediatamente se main mudou, patch/19 caminhos/hashes não conferem, Codex novo ainda habilita HIVE, a correção pede arquivo fora da allowlist, proteção da PR #169 se perde, surgem erros HIGH/CRITICAL sem solução no escopo, teste obrigatório não completa, fonte primária inexiste ou qualquer comando exigiria tocar no HIVE antigo. Não improvisar, não pular gates e não expandir a versão.

Este CD20-R6-C5 termina no candidato LOCAL e Evidence Bundle, ou em STOP com correção fechada. Nenhuma publicação/merge, nenhuma declaração de C07 PASS, nenhuma declaração de instalação HIVE removida, nenhuma mudança de checkpoint.
